#!/bin/env sh

echo -e "Opening directory with saves, settings and custom levels…"
xdg-open "$HOME/.local/share/godot/app_userdata/LAEC IS YOU/"

echo -e "Goodbye!"
